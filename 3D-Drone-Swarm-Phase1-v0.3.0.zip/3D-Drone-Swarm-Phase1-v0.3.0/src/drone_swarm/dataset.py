"""Dataset catalog construction for collections of successful swarm runs."""

from __future__ import annotations

import json
import os
import re
from collections import Counter
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from drone_swarm.contracts import (
    DATASET_CONTRACT_VERSION,
    MANIFEST_COLUMNS,
    MANIFEST_TEMPLATE,
    TABLE_GLOBAL_PRIMARY_KEYS,
    TABLE_PRIMARY_KEYS,
    TABLE_SEMANTICS,
    TABLE_STEMS,
    preferred_resource_file,
)
from drone_swarm.io import atomic_write_json, sha256_file, write_records_csv, write_records_parquet
from drone_swarm.schema_resources import write_schema
from drone_swarm.validation import ValidationLevel, validate_run_directory


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as file_obj:
        value = json.load(file_obj)
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _atomic_replace_table(
    write_function: Callable[..., None],
    records: list[dict[str, Any]],
    path: Path,
    *,
    columns: Sequence[str] | None = None,
    template: Mapping[str, Any] | None = None,
) -> None:
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    write_function(records, temporary, columns=columns, template=template)
    os.replace(temporary, path)


def _run_directories(raw_root: Path) -> tuple[list[Path], list[str]]:
    successful: list[Path] = []
    incomplete: list[str] = []
    if not raw_root.is_dir():
        return successful, incomplete
    for directory in sorted(raw_root.iterdir()):
        if not directory.is_dir():
            continue
        if directory.name.startswith("."):
            if ".partial-" in directory.name:
                incomplete.append(directory.name)
            continue
        required = ("_SUCCESS", "manifest_row.json", "artifact_manifest.json")
        if all((directory / name).is_file() for name in required):
            successful.append(directory)
        else:
            incomplete.append(directory.name)
    return successful, incomplete


def _schema_registry(run_artifacts: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    registry: dict[str, Any] = {}
    for stem in TABLE_STEMS:
        fingerprints: Counter[str] = Counter()
        example: Mapping[str, Any] | None = None
        formats: Counter[str] = Counter()
        for artifacts in run_artifacts:
            selected = preferred_resource_file(artifacts, stem)
            if selected is None:
                continue
            fingerprint = str(selected.get("schema_fingerprint", "unknown"))
            fingerprints[fingerprint] += 1
            formats[str(selected.get("format", "unknown"))] += 1
            if example is None:
                example = selected
        if example is None:
            continue
        registry[stem] = {
            "description": TABLE_SEMANTICS[stem],
            "contract_version": next(
                (
                    str(resource.get("contract_version"))
                    for artifacts in run_artifacts
                    for resource in artifacts.get("resources", ())
                    if isinstance(resource, Mapping) and resource.get("name") == stem
                ),
                None,
            ),
            "primary_key_within_run": list(TABLE_PRIMARY_KEYS[stem]),
            "global_primary_key": list(TABLE_GLOBAL_PRIMARY_KEYS[stem]),
            "observed_formats": dict(sorted(formats.items())),
            "schema_fingerprints": dict(sorted(fingerprints.items())),
            "schema_consistent": len(fingerprints) == 1,
            "column_count": int(example.get("column_count", 0)),
            "columns": example.get("columns", []),
        }
    return registry


def _table_globs(run_artifacts: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    tables: dict[str, Any] = {}
    for stem in TABLE_STEMS:
        formats: Counter[str] = Counter()
        for artifacts in run_artifacts:
            resource = next(
                (
                    item
                    for item in artifacts.get("resources", ())
                    if isinstance(item, Mapping) and item.get("name") == stem
                ),
                None,
            )
            if resource is None:
                continue
            for file_value in resource.get("files", ()):
                if isinstance(file_value, Mapping):
                    formats[str(file_value.get("format", "unknown"))] += 1
        if not formats:
            continue
        paths = {
            format_name: f"raw/*/{stem}.{format_name}"
            for format_name in ("parquet", "csv", "jsonl")
            if format_name in formats
        }
        preferred = next(
            (value for value in ("parquet", "csv", "jsonl") if value in paths),
            next(iter(paths)),
        )
        tables[stem] = {
            "description": TABLE_SEMANTICS[stem],
            "primary_key_within_run": list(TABLE_PRIMARY_KEYS[stem]),
            "global_primary_key": list(TABLE_GLOBAL_PRIMARY_KEYS[stem]),
            "preferred_format": preferred,
            "path_globs": paths,
            "run_file_counts": dict(sorted(formats.items())),
        }
    return tables


def _pairing_warnings(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    available = {
        (str(row.get("scenario_id")), int(row.get("base_seed", 0))) for row in rows
    }
    warnings: list[dict[str, Any]] = []
    for row in rows:
        control = row.get("paired_control_scenario")
        if not control:
            continue
        key = (str(control), int(row.get("base_seed", 0)))
        if key not in available:
            warnings.append(
                {
                    "run_id": row.get("run_id"),
                    "scenario_id": row.get("scenario_id"),
                    "base_seed": row.get("base_seed"),
                    "missing_control_scenario": control,
                }
            )
    return warnings


def _duplicate_values(rows: Sequence[Mapping[str, Any]], field: str) -> list[str]:
    counts = Counter(str(row.get(field, "")) for row in rows)
    return sorted(value for value, count in counts.items() if value and count > 1)


def _duckdb_sql(tables: Mapping[str, Any], *, manifest_parquet: bool) -> str:
    lines = [
        "-- Generated by `drone-swarm catalog`. Execute from the dataset root.",
        "-- The filename column preserves source-file provenance.",
        "",
    ]
    if manifest_parquet:
        lines.append(
            "CREATE OR REPLACE VIEW manifest AS "
            "SELECT * FROM read_parquet('manifest.parquet');"
        )
    else:
        lines.append(
            "CREATE OR REPLACE VIEW manifest AS "
            "SELECT * FROM read_csv_auto('manifest.csv', header=true);"
        )
    for name, table in tables.items():
        if not isinstance(table, Mapping):
            continue
        paths = table.get("path_globs", {})
        if not isinstance(paths, Mapping):
            continue
        if "parquet" in paths:
            glob = str(paths["parquet"]).replace("'", "''")
            lines.append(
                f"CREATE OR REPLACE VIEW {name} AS SELECT * "
                f"FROM read_parquet('{glob}', union_by_name=true, filename=true);"
            )
        elif "csv" in paths:
            glob = str(paths["csv"]).replace("'", "''")
            lines.append(
                f"CREATE OR REPLACE VIEW {name} AS SELECT * "
                f"FROM read_csv_auto('{glob}', union_by_name=true, header=true, filename=true);"
            )
    lines.append("")
    return "\n".join(lines)


def _package_name(value: str) -> str:
    cleaned = re.sub(r"[^a-z0-9._-]+", "-", value.lower()).strip("-.")
    return cleaned or "drone-swarm-dataset"


def _datapackage(
    root: Path,
    *,
    tables: Mapping[str, Any],
    schema_registry: Mapping[str, Any],
    manifest_parquet: bool,
    generated_at: str,
) -> dict[str, Any]:
    resources: list[dict[str, Any]] = [
        {
            "name": "manifest",
            "path": "manifest.parquet" if manifest_parquet else "manifest.csv",
            "profile": "tabular-data-resource",
            "format": "parquet" if manifest_parquet else "csv",
            "description": "One row per successful independent simulation run.",
        }
    ]
    registry_tables = schema_registry.get("tables", {})
    for name, table in tables.items():
        if not isinstance(table, Mapping):
            continue
        preferred = str(table.get("preferred_format", "parquet"))
        paths = table.get("path_globs", {})
        if not isinstance(paths, Mapping) or preferred not in paths:
            continue
        resource: dict[str, Any] = {
            "name": name,
            "path": str(paths[preferred]),
            "profile": "tabular-data-resource",
            "format": preferred,
            "description": table.get("description"),
            "primaryKey": table.get("global_primary_key", []),
        }
        schema_value = registry_tables.get(name, {}) if isinstance(registry_tables, Mapping) else {}
        if isinstance(schema_value, Mapping):
            resource["x-arrow-schema-fingerprint"] = next(
                iter(schema_value.get("schema_fingerprints", {})), None
            )
            resource["x-column-count"] = schema_value.get("column_count")
        resources.append(resource)
    return {
        "profile": "tabular-data-package",
        "name": _package_name(root.name),
        "title": "Drone swarm simulation dataset",
        "created": generated_at,
        "licenses": [{"name": "MIT", "path": "https://opensource.org/license/mit"}],
        "sources": [
            {
                "title": "3D-Drone-Swarm repository",
                "path": "https://github.com/DemetersSon83/3D-Drone-Swarm",
            }
        ],
        "resources": resources,
        "x-dataset-contract-version": DATASET_CONTRACT_VERSION,
    }


def _dataset_card(
    *,
    root: Path,
    summary: Mapping[str, Any],
    tables: Mapping[str, Any],
) -> str:
    lines = [
        "# Drone Swarm Dataset Card",
        "",
        f"- Dataset ID: `{root.name}`",
        f"- Contract version: `{DATASET_CONTRACT_VERSION}`",
        f"- Successful runs: **{summary.get('successful_runs', 0)}**",
        f"- Transition rows: **{summary.get('transition_rows', 0):,}**",
        f"- Agent-signal rows: **{summary.get('agent_signal_rows', 0):,}**",
        f"- Quality status: **{summary.get('quality_status', 'unknown')}**",
        "",
        "## Scenario coverage",
        "",
    ]
    scenario_counts = summary.get("scenario_counts", {})
    if isinstance(scenario_counts, Mapping) and scenario_counts:
        lines.extend(
            f"- `{scenario}`: {count} run(s)"
            for scenario, count in sorted(scenario_counts.items())
        )
    else:
        lines.append("No successful runs were cataloged.")
    lines.extend(["", "## Tables", ""])
    for name, table in tables.items():
        if not isinstance(table, Mapping):
            continue
        lines.append(f"### `{name}`")
        lines.append("")
        lines.append(str(table.get("description", "")))
        lines.append("")
        lines.append(
            "Within-run primary key: `"
            + "`, `".join(str(value) for value in table.get("primary_key_within_run", ()))
            + "`."
        )
        lines.append(
            "Dataset-global primary key: `"
            + "`, `".join(str(value) for value in table.get("global_primary_key", ()))
            + "`."
        )
        lines.append("")
    lines.extend(
        [
            "## Loading",
            "",
            "```python",
            "from drone_swarm.loaders import DroneSwarmDataset",
            "",
            "dataset = DroneSwarmDataset('.')",
            "manifest = dataset.manifest_pandas()",
            "signals = dataset.read_pandas('agent_signals', scenario_ids=['split_step'])",
            "```",
            "",
            "DuckDB users can execute `sql/duckdb_views.sql` from the dataset root.",
            "Use only run directories containing `_SUCCESS`, and inspect",
            "`quality_report.json` before inferential analysis.",
            "",
        ]
    )
    return "\n".join(lines)


def _write_checksums(
    output_root: Path,
    run_artifacts: Sequence[tuple[Path, Mapping[str, Any]]],
) -> None:
    entries: list[tuple[str, str]] = []
    for directory, artifacts in run_artifacts:
        for resource in artifacts.get("resources", ()):
            if not isinstance(resource, Mapping):
                continue
            for file_value in resource.get("files", ()):
                if not isinstance(file_value, Mapping):
                    continue
                relative = directory.relative_to(output_root) / str(file_value.get("path"))
                entries.append((str(file_value.get("sha256")), relative.as_posix()))
        for name in (
            "config.json",
            "provenance.json",
            "manifest_row.json",
            "artifact_manifest.json",
            "quality_report.json",
            "events.json",
            "_SUCCESS",
        ):
            path = directory / name
            if path.is_file():
                entries.append((sha256_file(path), path.relative_to(output_root).as_posix()))
    for name in (
        "manifest.csv",
        "manifest.parquet",
        "dataset_summary.json",
        "dataset_catalog.json",
        "schema_registry.json",
        "datapackage.json",
        "quality_report.json",
        "DATASET_CARD.md",
        "sql/duckdb_views.sql",
        "schemas/scenario.schema.json",
        "schemas/artifact-manifest.schema.json",
        "schemas/dataset-catalog.schema.json",
    ):
        path = output_root / name
        if path.is_file():
            entries.append((sha256_file(path), path.relative_to(output_root).as_posix()))
    entries.sort(key=lambda item: item[1])
    temporary = output_root / f".checksums.sha256.tmp-{os.getpid()}"
    with temporary.open("w", encoding="utf-8") as file_obj:
        for digest, relative in entries:
            file_obj.write(f"{digest}  {relative}\n")
    os.replace(temporary, output_root / "checksums.sha256")


def build_dataset_catalog(
    output_root: str | Path,
    *,
    strict: bool = False,
    no_parquet: bool = False,
    validate_runs: bool = True,
    validation_level: ValidationLevel = "quick",
) -> dict[str, Any]:
    """Build manifests, schemas, catalog, checksums, SQL views, and quality results."""

    root = Path(output_root).resolve()
    raw_root = root / "raw"
    root.mkdir(parents=True, exist_ok=True)
    run_directories, incomplete = _run_directories(raw_root)

    rows: list[dict[str, Any]] = []
    artifact_values: list[dict[str, Any]] = []
    run_artifact_pairs: list[tuple[Path, Mapping[str, Any]]] = []
    run_quality: list[dict[str, Any]] = []
    for directory in run_directories:
        row = _load_json(directory / "manifest_row.json")
        artifacts = _load_json(directory / "artifact_manifest.json")
        row["run_path"] = directory.relative_to(root).as_posix()
        for table_name in TABLE_STEMS:
            selected = preferred_resource_file(artifacts, table_name)
            row[f"{table_name}_path"] = (
                None
                if selected is None
                else (directory.relative_to(root) / str(selected["path"])).as_posix()
            )
        rows.append(row)
        artifact_values.append(artifacts)
        run_artifact_pairs.append((directory, artifacts))
        if validate_runs:
            report = validate_run_directory(
                directory,
                level=validation_level,
                require_success=True,
                verify_checksums=False,
            )
        elif (directory / "quality_report.json").is_file():
            report = _load_json(directory / "quality_report.json")
        else:
            report = {"path": str(directory), "status": "unknown", "checks": []}
        run_quality.append(report)

    rows.sort(key=lambda row: (str(row.get("scenario_id")), int(row.get("base_seed", 0))))
    _atomic_replace_table(
        write_records_csv,
        rows,
        root / "manifest.csv",
        columns=MANIFEST_COLUMNS,
        template=MANIFEST_TEMPLATE,
    )
    manifest_parquet_written = False
    if not no_parquet:
        try:
            _atomic_replace_table(
                write_records_parquet,
                rows,
                root / "manifest.parquet",
                columns=MANIFEST_COLUMNS,
                template=MANIFEST_TEMPLATE,
            )
            manifest_parquet_written = True
        except RuntimeError:
            manifest_parquet_written = False

    generated_at = _utc_now()
    schema_root = root / "schemas"
    write_schema("scenario", schema_root / "scenario.schema.json")
    write_schema("artifact-manifest", schema_root / "artifact-manifest.schema.json")
    write_schema("dataset-catalog", schema_root / "dataset-catalog.schema.json")

    schema_registry = {
        "contract_version": DATASET_CONTRACT_VERSION,
        "generated_at_utc": generated_at,
        "tables": _schema_registry(artifact_values),
    }
    atomic_write_json(root / "schema_registry.json", schema_registry)

    tables = _table_globs(artifact_values)
    catalog = {
        "contract_version": DATASET_CONTRACT_VERSION,
        "dataset_id": root.name,
        "generated_at_utc": generated_at,
        "root": ".",
        "run_count": len(rows),
        "manifest": {
            "csv": "manifest.csv",
            "parquet": "manifest.parquet" if manifest_parquet_written else None,
        },
        "tables": tables,
        "schema_registry": "schema_registry.json",
        "schemas": {
            "scenario": "schemas/scenario.schema.json",
            "artifact_manifest": "schemas/artifact-manifest.schema.json",
            "dataset_catalog": "schemas/dataset-catalog.schema.json",
        },
        "datapackage": "datapackage.json",
        "dataset_card": "DATASET_CARD.md",
        "quality_report": "quality_report.json",
        "checksums": "checksums.sha256",
        "duckdb_views": "sql/duckdb_views.sql",
    }
    atomic_write_json(root / "dataset_catalog.json", catalog)
    atomic_write_json(
        root / "datapackage.json",
        _datapackage(
            root,
            tables=tables,
            schema_registry=schema_registry,
            manifest_parquet=manifest_parquet_written,
            generated_at=generated_at,
        ),
    )

    scenario_counts = Counter(str(row.get("scenario_id", "unknown")) for row in rows)
    split_counts = Counter(str(row.get("analysis_split", "unspecified")) for row in rows)
    pairing_warnings = _pairing_warnings(rows)
    schema_mismatches = [
        name
        for name, value in schema_registry["tables"].items()
        if isinstance(value, Mapping) and not value.get("schema_consistent", False)
    ]
    duplicate_run_ids = _duplicate_values(rows, "run_id")
    failed_runs = [report for report in run_quality if report.get("status") == "fail"]
    warning_runs = [report for report in run_quality if report.get("status") in {"warning", "unknown"}]
    no_successful_runs = not rows
    strict_findings = bool(
        incomplete
        or pairing_warnings
        or schema_mismatches
        or duplicate_run_ids
        or no_successful_runs
    )
    quality_status = (
        "fail"
        if failed_runs or duplicate_run_ids or (strict and strict_findings)
        else "warning"
        if strict_findings or warning_runs
        else "pass"
    )
    quality = {
        "validation_version": "1.0.0",
        "generated_at_utc": _utc_now(),
        "status": quality_status,
        "successful_runs": len(rows),
        "no_successful_runs": no_successful_runs,
        "incomplete_runs": incomplete,
        "failed_run_count": len(failed_runs),
        "warning_run_count": len(warning_runs),
        "duplicate_run_ids": duplicate_run_ids,
        "schema_mismatches": schema_mismatches,
        "pairing_warnings": pairing_warnings,
        "run_reports": run_quality,
    }
    atomic_write_json(root / "quality_report.json", quality)

    summary = {
        "contract_version": DATASET_CONTRACT_VERSION,
        "generated_at_utc": _utc_now(),
        "successful_runs": len(rows),
        "incomplete_runs": incomplete,
        "scenario_counts": dict(sorted(scenario_counts.items())),
        "analysis_split_counts": dict(sorted(split_counts.items())),
        "transition_rows": sum(int(row.get("transition_rows", 0)) for row in rows),
        "agent_signal_rows": sum(int(row.get("agent_signal_rows") or 0) for row in rows),
        "manifest_parquet_written": manifest_parquet_written,
        "quality_status": quality_status,
    }
    atomic_write_json(root / "dataset_summary.json", summary)
    (root / "DATASET_CARD.md").write_text(
        _dataset_card(root=root, summary=summary, tables=tables),
        encoding="utf-8",
    )

    sql_root = root / "sql"
    sql_root.mkdir(exist_ok=True)
    sql_path = sql_root / "duckdb_views.sql"
    temporary_sql = sql_path.with_name(f".{sql_path.name}.tmp-{os.getpid()}")
    temporary_sql.write_text(
        _duckdb_sql(tables, manifest_parquet=manifest_parquet_written),
        encoding="utf-8",
    )
    os.replace(temporary_sql, sql_path)

    _write_checksums(root, run_artifact_pairs)
    if quality_status != "fail":
        atomic_write_json(
            root / "_SUCCESS",
            {
                "contract_version": DATASET_CONTRACT_VERSION,
                "run_count": len(rows),
                "quality_status": quality_status,
                "completed_at_utc": _utc_now(),
            },
        )
    elif (root / "_SUCCESS").exists():
        (root / "_SUCCESS").unlink()

    return summary
